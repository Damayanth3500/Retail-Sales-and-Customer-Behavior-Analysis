# Retail Sales & Customer Behavior Analysis

**SQL / MySQL Data Analytics Project**

A portfolio project focused on analyzing retail transactions and customer behavior using relational SQL queries. The analysis covers revenue performance, customer segmentation, payment behavior, category trends, shopping-mall performance, and time-based sales patterns.

## Project Objective

Use SQL to turn transaction and customer data into measurable business insights while demonstrating practical database and analytical SQL skills.

## Dataset

The project uses two CSV files:

- `data/sales_data.csv` — transaction-level sales data.
- `data/customer_data.csv` — customer demographics and payment method.

### Main fields

**Sales:** invoice number, customer ID, category, quantity, price, invoice date, shopping mall.

**Customer:** customer ID, gender, age, payment method.

## Tech Stack

- MySQL 8+
- SQL
- MySQL Workbench
- CSV
- Git / GitHub

## SQL Concepts Demonstrated

- SELECT, WHERE, ORDER BY
- GROUP BY and HAVING
- Aggregate functions
- INNER / LEFT JOIN
- CASE expressions
- Common Table Expressions (CTEs)
- Subqueries
- Window functions (`DENSE_RANK`, `ROW_NUMBER`)
- Date-based aggregation
- Customer segmentation
- Index creation
- Data-quality checks

## Project Structure

```text
Retail-Sales-and-Customer-Behavior-Analysis/
├── data/
│   ├── customer_data.csv
│   └── sales_data.csv
├── sql/
│   ├── 01_schema.sql
│   └── 02_analysis.sql
├── docs/
│   └── insights.md
└── README.md
```

## How to Run

1. Install MySQL 8+ and open MySQL Workbench.
2. Run `sql/01_schema.sql` to create the database and tables.
3. Import `data/customer_data.csv` into `customer_data`.
4. Import `data/sales_data.csv` into `sales_data`.
5. Run `sql/02_analysis.sql` query by query or as a script.
6. Review the result sets and compare them with `docs/insights.md`.

## Verified Dataset Results

The supplied data contains **99,457 transactions** and **99,457 unique customers**, with total calculated revenue of **$251,505,794.25**. The average transaction value calculated from the transaction rows is **$2,528.79**.

The largest category by calculated revenue is Clothing, followed by Shoes and Technology. The detailed figures are available in `docs/insights.md`.

## Resume Description

**Retail Sales & Customer Behavior Analysis | SQL, MySQL**

- Analyzed 99K+ retail transactions using MySQL to identify revenue trends, customer behavior, product-category performance, and shopping-mall sales patterns.
- Built SQL analysis using joins, CTEs, subqueries, CASE expressions, aggregations, and window functions for customer segmentation and ranking.
- Performed data-quality checks and translated transaction-level data into measurable business insights using category, demographic, payment, and time-based analysis.

## Portfolio Note

This repository is a personalized implementation based on a publicly available retail analytics dataset/project structure. The SQL organization, documentation, validation, and analysis in this version were rewritten for this portfolio. The underlying CSV data remains the supplied dataset.
